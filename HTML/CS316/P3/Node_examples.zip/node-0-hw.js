var hw = "Hello, World!";

console.log(hw);
