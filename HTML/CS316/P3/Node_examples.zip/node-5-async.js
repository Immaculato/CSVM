console.log('Hi');

setTimeout(function cb() {
	console.log('there');
	},
	0);

console.log('CS316 class');
