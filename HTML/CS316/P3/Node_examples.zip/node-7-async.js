setTimeout(function timeout() {
	console.log('hi 1');
	}, 3000
	);

setTimeout(function timeout() {
	console.log('hi 2');
	}, 3000
	);

setTimeout(function timeout() {
	console.log('hi 3');
	}, 2000
	);

setTimeout(function timeout() {
	console.log('hi 4');
	}, 1000
	);

console.log('Hello, world');
//delay();
console.log('How are you?');
